import numpy as np
from multiagent.core import World
from multiagent.scenario import BaseScenario
import networkx as nx
import datetime

class Agent():
    def __init__(self)

class Scenario(BaseScenario):
    def make_world(self):
        # 创建世界对象
        world = World()
        world.interface_relations = {}
        world.node_to_index={}
        world.hosts={}
        world.switches={}
        world.graph =nx.Graph()
        world.graph, world.hosts, world.switches, world.node_to_index, world.interface_relations=controller.init_topology(world.graph, world.hosts, world.switches, world.node_to_index, world.interface_relations)
        world.num_agents=7
        world.agents = [Agent() for i in range(world.num_agents)]
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.path_length=0
            agent.traffic_size=0
            agent.state = None
        subprocess.run("make run", shell=True,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        world.host_pids=get_mininet_host_pids()
        # 初始化环境
        self.reset_world(world)
        return world

    def reset_world(self, world):
        """
        重置环境，调用 chongzhi 函数。
        """
        subprocess.run(f"make clean", shell=True,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(f"make run", shell=True,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def get_mininet_host_pids():
        """
        查询所有 mininet 主机对应的进程 PID，返回字典 {host: pid}
        """
        try:
            # 执行 ps 命令查询 mininet 主机相关的进程
            result = subprocess.run(
                "ps -eo pid,cmd | grep 'mininet:h' | grep -v grep",
                shell=True, capture_output=True, text=True
            )

            host_pid_map = {}
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.strip().split(None, 1)
                    pid = int(parts[0])
                    cmd = parts[1]
                    if '--norc' in cmd and 'mininet:h' in cmd:
                        # 提取主机名（如 mininet:h1）
                        for token in cmd.split():
                            if 'mininet:h' in token:
                                host = token.split(':')[1]
                                host_pid_map[host] = pid
            return host_pid_map

        except Exception as e:
            print("发生错误：", e)
            return {}

    def reward(self, agent, world):
        """
        计算奖励：reward = 15-avg_delay
        """
        path='/home/p4/data/'+agent+'.drc'
        avg_delay=calculate_average_delay()
        # return avg_delay>15 ? 10*(15-avg_delay) : 15-avg_delay
        return 15-avg_delay


    def calculate_average_delay(file_path):
        """
        读取文件内容，计算延迟并返回平均延迟和延迟列表。
        
        :param file_path: 文件路径
        :return: (平均延迟, 延迟列表)
        """
        def parse_timestamp(timestamp):
            return datetime.datetime.strptime(timestamp, '%H:%M:%S.%f')

        def calculate_delay(recv_time, send_time):
            recv_dt = parse_timestamp(recv_time)
            send_dt = parse_timestamp(send_time)
            delay = (recv_dt - send_dt).total_seconds()
            return delay

        send_times = []
        delays = []
        with open(file_path, 'r') as file:
            lines = file.readlines()
            for line in lines[2:-1]:  # 跳过前两行和最后一行
                recv_time = line.split(' ')[0]
                send_time = line.split('sent>')[1].split(' ')[0]
                delay = calculate_delay(recv_time, send_time)
                send_times.append(parse_timestamp(send_time))
                delays.append(delay * 1000)  # 转换为毫秒

        # 计算相对发送时间
        start_time = send_times[0]
        relative_send_times = [(t - start_time).total_seconds() for t in send_times]

        # 筛选时间范围内的延迟
        filtered_delays = [
            delay for time, delay in zip(relative_send_times, delays) if 20 <= time <= 160
        ]

        # 计算平均延迟
        avg_delay = sum(filtered_delays) / len(filtered_delays) if filtered_delays else 0

        return avg_delay

    def observation(self, agent, world):
        """
        返回当前状态（state）。
        """
        lenth = agent.path_length
        size = agent.traffic_size
        return agent.state

    def step(self, world, action):
        """
        执行一步操作。
        :param world: 当前世界对象。
        :param action: 一个包含三个整数的列表 [a1, a2, a3]，满足 1 <= a1 < a2 < a3 <= 10000。
        :return: (state, reward)
        """
        # 检查 action 是否有效
        if len(action) != 3 or not (1 <= action[0] < action[1] < action[2] <= 10000):
            raise ValueError("Action must be a list of three integers: 1 <= a1 < a2 < a3 <= 10000")

        # 调用 fasong 函数计算新的状态
        a1, a2, a3 = action
        state = self.fasong(a1, a2, a3)

        # 计算奖励
        reward = 15 - state

        return state, reward

    def fasong(self, a1, a2, a3):
        """
        模拟 fasong 函数，接收三个整数并返回一个整数作为新的状态。
        :param a1: 第一个整数
        :param a2: 第二个整数
        :param a3: 第三个整数
        :return: 一个整数，表示新的状态
        """
        # 示例实现：返回三个数的平均值（可以根据实际需求修改）
        return (a1 + a2 + a3) // 3